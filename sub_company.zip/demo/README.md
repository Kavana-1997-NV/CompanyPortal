# RoleBasedAuthorization

Contains Spring boot projects that explains about Role Based Authorization in a Rest application using Spring Security 5.

Have implemented Method level security and URL level Security and configured it in WebSecurityConfigurerAdapter and in Controllers.
