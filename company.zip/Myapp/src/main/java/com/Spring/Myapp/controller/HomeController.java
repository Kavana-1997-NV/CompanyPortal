package com.Spring.Myapp.controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.Spring.Myapp.dao.HomeDao;
import com.Spring.Myapp.model.Hello;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Handles requests for the application home page.
 * testssss
 */
@Controller
public class HomeController {

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private HomeDao homeDao;

	/**
	 * Simply selects the home view to render by returning its name.
	 */ 
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String login(Locale locale, Model model) {


		return "login";
	}
	//for mail option from email id and password is not given that should be given in the servlet-context.xml
	@RequestMapping(value = "/a", method = RequestMethod.GET)
	public String Home(Locale locale, Model model) {

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		//List<Hello> list = homeDao.getEmployees();
		Gson gson = new Gson();
		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "home";
	}
	@RequestMapping("/login")  
	   public ModelAndView Login(HttpServletRequest request,
			   HttpServletResponse response) {
		  String userName=request.getParameter("username");  
	      String password=request.getParameter("password");
	      String message;
	      System.out.println(userName +"-"+ password);
	      if(userName != null && !userName.equals("") && password != null && !password.equals("")){
	    	  //message = "Welcome " +userName + ".";
		      return new ModelAndView("home");  
	 
	      }else{
	    	  message = "Wrong username or password.";
	    	  return new ModelAndView("errorPage", 
	    			  "message", message);
	      }
	}
	@RequestMapping("/access")  
	   public ModelAndView Access(HttpServletRequest request,
			   HttpServletResponse response) {
		return new ModelAndView("access");
	}
	@RequestMapping("/accessRequest")  
	   public ModelAndView AccessRequest(HttpServletRequest request,
			   HttpServletResponse response) {
		  String userName=request.getParameter("username"); 
	      String message;
	      if(userName != null && !userName.equals("")){
		      return new ModelAndView("access");  
	 
	      }else{
	    	  message = "Wrong username";
	    	  return new ModelAndView("errorPage", 
	    			  "message", message);
	      }
	}
	/*
	 * @RequestMapping("/loginProcess") public String loginProcess(Model m) {
	 * m.addAttribute("command", new Hello()); return "empForm"; }
	 */
	@RequestMapping("/empForm")
	public String showform(Model m) {
		m.addAttribute("command", new Hello());
		return "empForm";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveEmp(@ModelAttribute("emp") Hello hello) {
		homeDao.save(hello);
		System.out.println("inside save");
		return "success";
	}
	
	@RequestMapping(value = "/viewemp")
	public String getallemps(Model m) {
		System.out.println("inside getEmpById controller");
		List<Hello> list = homeDao.getEmployees();
		m.addAttribute("list", list);
		return "viewemp";
	}
	
	@RequestMapping(value = "/editemp/{empID}")
	public String edit(@PathVariable int empID, Model m) {
		System.out.println("inside getEmpById controller");
		Hello emp = homeDao.getEmpById(empID); // System.out.println("getbyID"+emp);
		m.addAttribute("command", emp);
		return "empeditform";
	}

	@RequestMapping(value = "/updateemp", method = RequestMethod.POST)
	public String editsave(@ModelAttribute("emp") Hello hello) {
		homeDao.update(hello);
		return "redirect:/viewemp";
	}

	@RequestMapping(value = "/deleteemp/{empID}", method = RequestMethod.GET)
	public String delete(@PathVariable int empID) {
		homeDao.delete(empID);
		return "redirect:/viewemp";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login() {
		return "login";

	}
	 

	

	

}