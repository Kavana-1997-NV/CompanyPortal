/*
 * package com.Spring.Myapp.Util;
 * 
 * import java.net.URI;
 * 
 * import javax.ws.rs.core.MediaType; import javax.ws.rs.core.UriBuilder; import
 * javax.xml.bind.JAXBException;
 * 
 * import com.sun.jersey.api.client.Client; import
 * com.sun.jersey.api.client.WebResource; import
 * com.sun.jersey.api.client.config.ClientConfig; import
 * com.sun.jersey.api.client.config.DefaultClientConfig;
 * 
 * public class webServiceCall { public String callService(String classname,
 * String methodname,String xmlrequest) throws JAXBException{
 * 
 * 
 * String respData = null; System.out.println(classname + "  classname");
 * System.out.println(xmlrequest + "  Data"); try { ClientConfig config = new
 * DefaultClientConfig(); Client client = Client.create(config);
 * //client.addFilter(new HTTPBasicAuthFilter("DPCOMUSER", "BSID#03pcom"));
 * WebResource service = client.resource(getBaseURI());
 * 
 * 
 * 
 * respData =
 * service.path(classname).path(methodname).type(MediaType.APPLICATION_JSON).
 * post(String.class, xmlrequest); //System.out.println("respdata" + respData);
 * 
 * } catch (Exception e) { e.printStackTrace(); }
 * 
 * 
 * System.out.println("Response=" + respData); return respData; }
 * 
 * public URI getBaseURI() { System.out.println("inside url"); return
 * UriBuilder.fromUri("http://localhost:8080/bsdpws20/").build();
 * 
 * 
 * }
 * 
 * }
 */