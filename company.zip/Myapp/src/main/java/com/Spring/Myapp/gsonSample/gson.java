/*
 * package com.Spring.Myapp.gsonSample;
 * 
 * import java.io.BufferedReader; import java.io.FileNotFoundException; import
 * java.io.FileReader; import java.io.FileWriter; import java.io.IOException;
 * import java.util.List;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.ui.Model; import org.springframework.ui.ModelMap; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod;
 * 
 * import com.Spring.Myapp.dao.HomeDao; import com.Spring.Myapp.model.Hello;
 * import com.google.gson.Gson; import com.google.gson.GsonBuilder;
 * 
 * @Controller public class gson {
 * 
 * @Autowired private static HomeDao homeDao;
 * 
 * @RequestMapping(value = "/gson", method = RequestMethod.GET) public String
 * gsonabc(Model m, ModelMap modelMap) {
 * 
 * 
 * //String viewemp(Model m) { gson tester = new gson(); try { Hello student =
 * new Hello();
 * 
 * student.setAge(10); student.setName("Mahesh"); tester.writeJSON(student);
 * 
 * List<Hello> list = homeDao.getEmployees();
 * 
 * Hello student1 = tester.readJSON(); System.out.println(student1);
 * m.addAttribute("list", student1); } catch(FileNotFoundException e) {
 * e.printStackTrace(); } catch(IOException e) { e.printStackTrace(); } return
 * "success"; }
 * 
 * private void writeJSON(Hello student) throws IOException { GsonBuilder
 * builder = new GsonBuilder(); Gson gson = builder.create(); FileWriter writer
 * = new FileWriter("student.json"); writer.write(gson.toJson(student));
 * writer.close(); }
 * 
 * public Hello readJSON() throws FileNotFoundException { GsonBuilder builder =
 * new GsonBuilder(); Gson gson = builder.create(); BufferedReader
 * bufferedReader = new BufferedReader( new FileReader("student.json"));
 * 
 * Hello student = gson.fromJson(bufferedReader, Hello.class); return student; }
 * 
 * }
 * 
 */