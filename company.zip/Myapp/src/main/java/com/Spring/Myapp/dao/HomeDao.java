package com.Spring.Myapp.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.Spring.Myapp.model.Hello;

//import org.springframework.jdbc.core.Jdbctemplate;

@Configuration
@PropertySource("/resources/application.properties")
@Transactional
public class HomeDao {
	JdbcTemplate template;

	@Autowired
	private Environment env;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	DataSource ds;

	public DataSource getDataSource() {
		return this.ds;
	}

	public void setDataSource(DataSource ds) {
		this.ds = ds;
	}

	public Hello getEmpById(int empID) {
		System.out.println("inside getEmpById");
		String sql = "select * from employee where empID=?";
		return template.queryForObject(sql, new Object[] { empID }, new BeanPropertyRowMapper<Hello>(Hello.class));
	}

	// @Override

	/*
	 * public List<Map<String, Object>> getEmpById(int empID) {
	 * System.out.println("inside AdminReportsImpl"); List<Map<String, Object>>
	 * getReport = null; String sql = env.getRequiredProperty("getbyID"); getReport
	 * = template.queryForList(sql, empID); return getReport;
	 * 
	 * }
	 */

	public int update(Hello p) {
		String sql = "update employee set empName='" + p.getEmpName() + "',position='" + p.getPosition()
				+ "' where empID='" + p.getEmpID() + "'";
		System.out.println("update" + sql);
		return template.update(sql);
	}

	public int delete(int empID) {
		String sql = "delete from employee where empID=" + empID + "";
		return template.update(sql);
	}

	public List<Hello> getEmployees() {
		return template.query("select * from employee", new RowMapper<Hello>() {
			public Hello mapRow(ResultSet rs, int row) throws SQLException { //
				System.out.println("inside viewemp dAO");
				Hello e = new Hello();
				e.setEmpID(rs.getInt(1));
				e.setEmpName(rs.getString(2));
				e.setPosition(rs.getString(3));
				return e;
			}

		});
	}

	public int save(Hello p) {
		String sql = "insert into employee(empID,empName,position) values('" + p.getEmpID() + "','" + p.getEmpName()
				+ "','" + p.getPosition() + "')";
		return template.update(sql);
	}

	public List<Hello> getEmployeesByPage(int pageid, int total) {
		String sql = "select * from employee limit " + (pageid - 1) + "," + total;
		return template.query(sql, new RowMapper<Hello>() {
			public Hello mapRow(ResultSet rs, int row) throws SQLException {
				Hello e = new Hello();
				e.setEmpID(rs.getInt(1));
				e.setEmpName(rs.getString(2));
				e.setPosition(rs.getString(3));
				return e;
			}
		});
	}

}

